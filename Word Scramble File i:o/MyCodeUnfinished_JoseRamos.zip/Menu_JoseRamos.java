/* Guess What Number Lab
-- OBJECTIVE --
Create a game where the player can guess scrambled words.

  Name: Jose Ramos
  Date: March 14, 2019
*/

import java.util.*;

public class Menu_JoseRamos
{

    void printMenu()
    {
        System.out.println("******** Welcome to the scramble game ********");
        System.out.println("Enter a number from 1 to 3:\n1. Enter your information \n2. Play the game \n3. Game instructions");

    }

}
