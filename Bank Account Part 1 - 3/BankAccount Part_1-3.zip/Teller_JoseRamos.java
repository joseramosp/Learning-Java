import java.util.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Teller_JoseRamos
{
    public void generateAccounts()
    {
        BankAccount_JoseRamos richGuy = new BankAccount_JoseRamos();
        BankAccount_JoseRamos poorGuy = new BankAccount_JoseRamos();
        Savings_JoseRamos cheapGuy = new Savings_JoseRamos();
        Checking_JoseRamos bigSpender = new Checking_JoseRamos();

        richGuy.setAccount("Rich", "Guy", 10001, 25000);
        richGuy.deposit(30000);
        richGuy.withdraw(7500);
        richGuy.printTransaction();

        poorGuy.setAccount("Poor", "Guy", 10002, 20);
        poorGuy.deposit(30);
        poorGuy.withdraw(39.85);
        poorGuy.printTransaction();

        cheapGuy.setAccount("Cheap", "Guy", 10003, 5000);
        cheapGuy.deposit(30000);
        cheapGuy.withdraw(500);
        cheapGuy.setInterestRate(40);
        cheapGuy.printTransaction();
        cheapGuy.getInterestRate();

        bigSpender.setAccount("Big", "Spender", 10004, 6780);
        bigSpender.deposit(500);
        bigSpender.withdraw(4000);
        bigSpender.setFee(40);
        bigSpender.printTransaction();
        bigSpender.getFee();

    }
}
