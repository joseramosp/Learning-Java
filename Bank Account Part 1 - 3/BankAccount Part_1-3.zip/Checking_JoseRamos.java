import java.util.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Checking_JoseRamos extends BankAccount_JoseRamos
{
    String accountType = "Saving";

    double bouncedCheckFee = 35;

    public void setFee()
    {
        System.out.println("Enter new fee amout for bounced checks: ");
        bouncedCheckFee = userInput.nextDouble();
    }

    public void setFee(double fee)
    {
        bouncedCheckFee = fee;
    }

    public void getFee()
    {
        System.out.println("\nThe account fee is for bounced checks is: " + bouncedCheckFee);
    }

    public void printTransaction()
    {

        System.out.println("\n" + date.format(LocalDateTime.now()));
        System.out.println("Account owner/s: " + account_Owner.fName + " " + account_Owner.lName);
        System.out.println("Account number: " + accountNumber );
        System.out.println("Account type: " + accountType );
        System.out.println("Account Balance: " + accountBalance + "\n");
    }
}
