import java.util.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class BankAccount_JoseRamos
{
    Person account_Owner = new Person();
    int accountNumber;
    double accountBalance;

    DateTimeFormatter date = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
    LocalDateTime now = LocalDateTime.now();

    Scanner userInput = new Scanner(System.in);

    public void setAccount()
    {
        System.out.println("Enter account owner first name: ");
        account_Owner.fName = userInput.next();

        System.out.println("Enter account owner last name: ");
        account_Owner.lName = userInput.next();

        System.out.println("Enter the account number: ");
        accountNumber = userInput.nextInt();

        System.out.println("Enter the account's initial balance: ");
        accountBalance = userInput.nextDouble();

    }

    public void setAccount(String fName, String lName, int accountNumber, double initialBalance)
    {
        account_Owner.fName = fName;
        account_Owner.lName = lName;
        this.accountNumber = accountNumber;
        accountBalance = initialBalance;

    }

    public void deposit(double add)
    {
        //System.out.println("Enter the amount you want to deposit: ");
        accountBalance = accountBalance + add;

    }

    public void withdraw(double deduct)
    {
        //System.out.println("Enter the amount you want to withdraw: ");
        boolean isGrater = true;

        while(isGrater)
        {
            if(deduct <= accountBalance)
            {
                accountBalance = accountBalance - deduct;
                isGrater = false;
            }
            else
            {
                System.out.println("The amount that you want to withdraw is not available");
                System.out.println("Enter a different amount:");
                deduct = userInput.nextDouble();
            }
        }
    }

    public void printTransaction()
    {
        System.out.println("\n" + date.format(LocalDateTime.now()));
        System.out.println("Account owner/s: " + account_Owner.fName + " " + account_Owner.lName);
        System.out.println("Account number: " + accountNumber );
        System.out.println("Account Balance: " + accountBalance + "\n");
    }

    public static void main(String args[])
    {
        Scanner userInput = new Scanner(System.in);

        Teller_JoseRamos teller = new Teller_JoseRamos();

        teller.generateAccounts();

    }
}
