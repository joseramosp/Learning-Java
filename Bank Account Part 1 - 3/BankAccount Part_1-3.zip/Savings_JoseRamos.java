import java.util.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class Savings_JoseRamos extends BankAccount_JoseRamos
{

    String accountType = "Saving";
    double interestRate;

    public void setInterestRate()
    {
        System.out.println("Enter the interest rate of the account: ");
        interestRate = userInput.nextDouble();
    }

    public void setInterestRate(double rate)
    {
        interestRate = rate;
    }

    public void getInterestRate()
    {
        System.out.println("The account interest rate is " + interestRate + "%");
    }

    public void printTransaction()
    {

        System.out.println("\n" + date.format(LocalDateTime.now()));
        System.out.println("Account owner/s: " + account_Owner.fName + " " + account_Owner.lName);
        System.out.println("Account number: " + accountNumber );
        System.out.println("Account type: " + accountType );
        System.out.println("Account Balance: " + accountBalance + "\n");
    }
}
